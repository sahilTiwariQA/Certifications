$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/demos/Background.feature");
formatter.feature({
  "name": "Test the background feature in AUT",
  "description": "",
  "keyword": "Feature"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on EDU Teller Login Page",
  "keyword": "Given "
});
formatter.match({
  "location": "Background.user_is_on_EDU_Teller_Login_Page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "User checks for Add Money",
  "keyword": "When "
});
formatter.match({
  "location": "Background.user_checks_for_Add_Money()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter Account number details and Search",
  "keyword": "Then "
});
formatter.match({
  "location": "Background.enter_Account_number_details_and_Search()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Closes",
  "keyword": "And "
});
formatter.match({
  "location": "Background.closes()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User is on EDU Teller Login Page",
  "keyword": "Given "
});
formatter.match({
  "location": "Background.user_is_on_EDU_Teller_Login_Page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User checks for My Customers",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "The user checks for My Customers link",
  "keyword": "When "
});
formatter.match({
  "location": "Background.the_user_checks_for_My_Customers_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "All Customer details displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Background.all_Customer_details_displayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Closes The Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Background.closes_The_Browser()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/demos/TaggedHooks.feature");
formatter.feature({
  "name": "Tagged Hooks Implementation",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@LoginandSignUp"
    }
  ]
});
formatter.scenario({
  "name": "Login to Packand Go",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@LoginandSignUp"
    },
    {
      "name": "@Login"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Customer is in Giving Login Credentials",
  "keyword": "Given "
});
formatter.match({
  "location": "TaggedHooks.customer_is_in_Giving_Login_Credentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Customer is Logged in",
  "keyword": "Then "
});
formatter.match({
  "location": "TaggedHooks.customer_is_Logged_in()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "SignUpin Packand Go",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@LoginandSignUp"
    },
    {
      "name": "@SignUP"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Customer Fills the Sign In details",
  "keyword": "Given "
});
formatter.match({
  "location": "TaggedHooks.customer_Fills_the_Sign_In_details()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Customer Registerd in Pack and Go",
  "keyword": "Then "
});
formatter.match({
  "location": "TaggedHooks.customer_Registerd_in_Pack_and_Go()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/demos/Tags.feature");
formatter.feature({
  "name": "Tags in Feature FIle",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@OpenAUT"
    }
  ]
});
formatter.scenario({
  "name": "Open AUT and Print Title",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@OpenAUT"
    },
    {
      "name": "@EDUBankCustomer"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "The Customer is on EDU customer Login Page",
  "keyword": "Given "
});
formatter.match({
  "location": "Tags.the_Customer_is_on_EDU_customer_Login_Page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enters Login credentials",
  "keyword": "When "
});
formatter.match({
  "location": "Tags.enters_Login_credentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Get title of the Page Displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "Tags.get_title_of_the_Page_Displayed()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Open AUT and Print Title",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@OpenAUT"
    },
    {
      "name": "@EDUBankTeller"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "EDU Bank Teller Home Page",
  "keyword": "Given "
});
formatter.match({
  "location": "Tags.edu_Bank_Teller_Home_Page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enters login Details",
  "keyword": "When "
});
formatter.match({
  "location": "Tags.enters_login_Details()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Logged in",
  "keyword": "Then "
});
formatter.match({
  "location": "Tags.logged_in()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/demos/first.feature");
formatter.feature({
  "name": "EDU AUT Login",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Verify the Sign Up in  EDU Bank",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User navigates to the Home Page",
  "keyword": "Given "
});
formatter.match({
  "location": "First.user_navigates_to_the_Home_Page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user Enters the Signup Details",
  "keyword": "When "
});
formatter.match({
  "location": "First.user_Enters_the_Signup_Details()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Logged In to EDU",
  "keyword": "Then "
});
formatter.match({
  "location": "First.user_Logged_In_to_EDU()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/demos/para.feature");
formatter.feature({
  "name": "To check the Edit Profile  functionality for each user",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Successful login with valid credentials",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "user is on PackAndGo login page",
  "keyword": "Given "
});
formatter.step({
  "name": "user enters the \"\u003cusername\u003e\" and \"\u003cpassword\u003e\" credentials",
  "keyword": "When "
});
formatter.step({
  "name": "user logged in and checks for Edit Profile",
  "keyword": "Then "
});
formatter.step({
  "name": "user logout from application",
  "keyword": "And "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ]
    },
    {
      "cells": [
        "pgAlmacho",
        "freezeray"
      ]
    },
    {
      "cells": [
        "pgScarlet",
        "freezeray"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Successful login with valid credentials",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user is on PackAndGo login page",
  "keyword": "Given "
});
formatter.match({
  "location": "Parameterization.user_is_on_PackAndGo_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user enters the \"pgAlmacho\" and \"freezeray\" credentials",
  "keyword": "When "
});
formatter.match({
  "location": "Parameterization.user_enters_the_and_credentials(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user logged in and checks for Edit Profile",
  "keyword": "Then "
});
formatter.match({
  "location": "Parameterization.user_logged_in_and_checks_for_Edit_Profile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user logout from application",
  "keyword": "And "
});
formatter.match({
  "location": "Parameterization.user_logout_from_application()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Successful login with valid credentials",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user is on PackAndGo login page",
  "keyword": "Given "
});
formatter.match({
  "location": "Parameterization.user_is_on_PackAndGo_login_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user enters the \"pgScarlet\" and \"freezeray\" credentials",
  "keyword": "When "
});
formatter.match({
  "location": "Parameterization.user_enters_the_and_credentials(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user logged in and checks for Edit Profile",
  "keyword": "Then "
});
formatter.match({
  "location": "Parameterization.user_logged_in_and_checks_for_Edit_Profile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user logout from application",
  "keyword": "And "
});
formatter.match({
  "location": "Parameterization.user_logout_from_application()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});