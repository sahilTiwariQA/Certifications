package mavennew;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class EDUopen {
	
	static WebDriver driver1;
	static String url="http://localhost:8080/EDUBank/"; 
	@Given("^EDU Home Page$")
	public void edu_Home_Page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
		System.setProperty("webdriver.gecko.driver","/root/Desktop/SuppliedFiles/geckodriver");
	    driver1 = new FirefoxDriver();
	    driver1.get(url);
		driver1.manage().timeouts().implicitlyWait(30000,TimeUnit.MILLISECONDS);
	}

	@Then("^The Title is$")
	public void the_Title_is() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	    System.out.println(driver1.getTitle());
		driver1.quit();
	}


}
